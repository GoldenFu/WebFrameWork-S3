from django.shortcuts import render
from django.http import HttpResponse
from .models import Post, Rating

# Create your views here.

def index(request):
    postsQuerySet = Post.objects.all()
    ratingList = Rating.objects.all()
    return render (request, "index.html" ,{ "posts" : postsQuerySet , "ratings": ratingList})